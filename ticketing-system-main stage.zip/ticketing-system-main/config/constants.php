<?php
define('ROLE_CLIENT', 'client');
define('ROLE_AGENT', 'agent');
define('ROLE_SUPPORT', 'support');
define('ROLE_ADMIN', 'admin');
?>
